package com.tts.twitter.controller;

import com.tts.twitter.model.User;
import com.tts.twitter.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.validation.Valid;

@Controller
public class AuthorizationController {

    @Autowired
    private UserService userService;

    @GetMapping(value = "/login")
    public String login() {
        return "login";
    }

    @GetMapping(value="/signup")
    public String registration(Model model){
        User User = new User();
        model.addAttribute("user", User);
        return "registration";
    }

    @PostMapping(value = "/signup")
    public String createNewUser(@Valid User User, BindingResult bindingResult, Model model) {
        com.tts.twitter.model.User userExists = userService.findByUsername(User.getUsername());
        if (userExists != null) {
            bindingResult.rejectValue("username", "error.User", "Username is already taken");
        }
        if (!bindingResult.hasErrors()) {
            userService.saveNewUser(User);
            model.addAttribute("success", "Sign up successful!");
            model.addAttribute("user", new User());
        }
        return "registration";
    }
}
