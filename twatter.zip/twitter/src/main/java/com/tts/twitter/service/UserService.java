package com.tts.twitter.service;

import com.tts.twitter.model.User;
import com.tts.twitter.model.Role;
import com.tts.twitter.repository.RoleRepository;
import com.tts.twitter.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

@Service
public class UserService {

    private UserRepository userRepository;
    private RoleRepository roleRepository;
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @Autowired
    public UserService(UserRepository userRepository,
                       RoleRepository roleRepository,
                       BCryptPasswordEncoder bCryptPasswordEncoder)
    {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.bCryptPasswordEncoder = bCryptPasswordEncoder;
    }

    public User findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public List<User> findAll(){
        return (List<User>) userRepository.findAll();
    }

    public void save(User User) {
        userRepository.save(User);
    }

    public User saveNewUser(User User) {
        User.setPassword(bCryptPasswordEncoder.encode(User.getPassword()));
        User.setActive(1);
        Role userRole = roleRepository.findByRole("USER");
        User.setRoles(new HashSet<>(Arrays.asList(userRole)));
        return userRepository.save(User);
    }

    public User getLoggedInUser() {
        String loggedInUsername = SecurityContextHolder.
                getContext().getAuthentication().getName();
        return findByUsername(loggedInUsername);
    }


}
